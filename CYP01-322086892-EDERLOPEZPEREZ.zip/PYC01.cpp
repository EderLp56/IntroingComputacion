#include <stdio.h>
int main()
{
	float ejex = 0.5 * 640 / 0.23;
	float ejey = 0.1 * 488 / 0.80;
	printf("(%.4f) y (%.4f)", ejex, ejey);
}